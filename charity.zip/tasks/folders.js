/**
 * Set paths
 * -----------------------------------------------------------------------------
 */

const folders = {
	build: 'static/build',
	src: 'static/src'
};


export default folders;